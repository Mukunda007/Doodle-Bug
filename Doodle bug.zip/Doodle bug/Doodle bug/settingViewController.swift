//
//  settingViewController.swift
//  Doodle bug
//
//  Created by Mukunda Pote on 10/09/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit
protocol SettingsViewControllerDelegate: class {
    
    func SettingsViewControllerFinished(_settinsViewController: settingViewController)

}


class settingViewController: UIViewController {
    
     var delegate: SettingsViewControllerDelegate?

    @IBOutlet weak var imageview: UIImageView!
    
    
    @IBOutlet weak var brush: UILabel!
    @IBOutlet weak var brushSlider: UISlider!
    
    @IBOutlet weak var opacityLabel: UILabel!
    @IBOutlet weak var opacitySlider: UISlider!
    
    @IBOutlet weak var colorsLabel: UILabel!
    
    @IBOutlet weak var redslider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    
    var brushwidth : CGFloat = 5
    
    var red : CGFloat = 0
    var green : CGFloat = 0
    var blue : CGFloat = 0
    
    var opacity : CGFloat = 1
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        brush.text = String(format: "Brush Size: %.0f", brushwidth)
        brushSlider.value = Float(brushwidth)
        
        redslider.value = Float(red*255)
        greenSlider.value = Float(green*255)
        blueSlider.value = Float(blue*255)
        
         redLabel.text = String(format: "%.0f", redslider.value)
        greenLabel.text = String(format: "%.0f", greenSlider.value)
        blueLabel.text = String(format: "%.0f", blueSlider.value)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.updatePreview()
    }
    
    @IBAction func exit(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        self.delegate?.SettingsViewControllerFinished(_settinsViewController: self)
    }
   
    
    @IBAction func opacityChange(_ sender: Any) {
        opacity = CGFloat(opacitySlider.value)
        opacityLabel.text = String(format: "Opacity: %.1f", opacity)
        self.updatePreview()

    }
   
    @IBAction func brushsize(_ sender: Any) {
        
        brushwidth = CGFloat(round(brushSlider.value))
        brush.text = String(format: "%0.f", brushwidth)
        self.updatePreview()
        
    }
    @IBAction func redColor(_ sender: Any) {
        red = CGFloat(redslider.value/255)
        redLabel.text = String(format: "%.0f", redslider.value)
        self.updatePreview()
    }
    
    
    @IBAction func greenColor(_ sender: Any) {
        green = CGFloat(greenSlider.value/255)
        greenLabel.text = String(format: "%.0f", greenSlider.value)
       self.updatePreview()
        
    }
    
    @IBAction func blueColor(_ sender: Any) {
        blue = CGFloat(blueSlider.value/255)
        blueLabel.text = String(format: "%.0f", blueSlider.value)
        self.updatePreview()
    }
    
    
    func updatePreview(){
        UIGraphicsBeginImageContext(imageview.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        context?.setLineCap(CGLineCap.round)
        context?.setLineWidth(brushwidth)
        
        context?.setStrokeColor(red: red, green: green, blue: blue, alpha: opacity)
        
        context?.move(to: CGPoint(x: 158, y: 158))
        context?.addLine(to: CGPoint(x: 158, y: 158))
        
        context?.strokePath()
        
        imageview.image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
    }
}
