//
//  ViewController.swift
//  Doodle bug
//
//  Created by Mukunda Pote on 03/09/20.
//  Copyright © 2020 Mukunda Pote. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
   
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var plusButton: UIButton!
    @IBOutlet weak var minusButton: UIButton!
    
    
    @IBOutlet weak var secondImage: UIImageView!
    
    @IBOutlet weak var hideButton: UIButton!
    @IBOutlet weak var prestackButton: UIStackView!
    
    @IBOutlet weak var reset: UIButton!
    @IBOutlet weak var setting: UIButton!
    @IBOutlet weak var save: UIButton!
    
    
    
    
    var lastPoint = CGPoint.zero
    var swiped = false
    @IBOutlet weak var label: UILabel!
    
    var red : CGFloat = 0
    var green: CGFloat = 0
    var blue: CGFloat = 0
    
    var brushWidth: CGFloat = 5
    
    var opacity: CGFloat = 1
    
    var hidestate = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = false
        
        if let touch = touches.first as UITouch? {
            lastPoint = touch.location(in: view.self)
            
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = true
        
        if let touch = touches.first as UITouch?{
            
           let currentPoint = touch.location(in: view)
            drawLine(lastPoint, toPoint: currentPoint)
            
            lastPoint = currentPoint
            
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !swiped {
            drawLine(lastPoint, toPoint: lastPoint)
        }
       
        UIGraphicsBeginImageContext(view.frame.size)
        
        imageView.image?.draw(in: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height),blendMode: CGBlendMode.normal, alpha: 1)
        
        secondImage.image?.draw(in: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height),blendMode: CGBlendMode.normal, alpha: opacity)
        
        
        imageView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        secondImage.image = nil
       
    }
    
    func drawLine(_ fromPoint: CGPoint, toPoint: CGPoint){
        UIGraphicsBeginImageContext(view.frame.size)
        let context = UIGraphicsGetCurrentContext()
        
        secondImage.image?.draw(in: CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height))
        context?.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y))
        context?.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y))
        
        context?.setLineCap(CGLineCap.round)
        context?.setStrokeColor(red: red, green: green, blue: blue, alpha: opacity)
        context?.setLineWidth(brushWidth)
        context?.setBlendMode(CGBlendMode.normal)
        
        context?.strokePath()
        
        
      secondImage.image  = UIGraphicsGetImageFromCurrentImageContext()
        secondImage.alpha = opacity
        UIGraphicsEndImageContext()
        
}
    
    @IBAction func red(_ sender: Any) {
        
        (red,green,blue) = (255,0,0)
    }
    
    @IBAction func green(_ sender: Any) {
        (red,green,blue) = (0,255,0)
    }
    
    @IBAction func blue(_ sender: Any) {
        (red,green,blue) = (0,0,255)
    }
    
    @IBAction func black(_ sender: Any) {
        (red,green,blue) = (0,0,0)
    }
    
    @IBAction func white(_ sender: Any) {
        (red,green,blue) = (255,255,255)
    }
    
    @IBAction func large(_ sender: Any) {
        brushWidth += 1
        self.brushSize()
    }
    
    @IBAction func small(_ sender: Any) {
        brushWidth -= 1
        self.brushSize()
    }
    
    func brushSize(){
       label.text = String(format: "%.0f", brushWidth)
        
        if brushWidth == 100 {
            
            plusButton.isEnabled = false
            
            plusButton.alpha = 0.25
        }
        else if brushWidth == 1 {
            
            minusButton.isEnabled = false
            minusButton.alpha = 0.25
        }
        else{
            plusButton.isEnabled = true
            plusButton.alpha = 1
            
            minusButton.isEnabled = true
            minusButton.alpha = 1
        }
    }
    
    @IBAction func reset(_ sender: Any) {
        imageView.image = nil
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let settingViewController = segue.destination as! settingViewController
        settingViewController.delegate = self
        settingViewController.brushwidth = brushWidth
        
        settingViewController.red = self.red
        settingViewController.green = self.green
        settingViewController.blue = self.blue
        settingViewController.opacity = self.opacity
    }
    
    @IBAction func save(_ sender: Any) {
        UIGraphicsBeginImageContext(imageView.bounds.size)
       
        
        imageView.image?.draw(in: CGRect(x: 0, y: 0, width: imageView.frame.size.width, height: imageView.frame.size.height))
        
      
         let image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        let activity = UIActivityViewController(activityItems: [image!], applicationActivities: nil)
        
        present(activity, animated: true, completion: nil)
    }
    
    @IBAction func hiderevealButton(_ sender: Any) {
        
        if hidestate == false{
            
            prestackButton.isHidden = true
            reset.isHidden = true
            setting.isHidden = true
            save.isHidden = true
            hideButton.setTitle("Reveal", for: UIControl.State.normal)
            hideButton.alpha = 0.2
            hidestate = true
            
        }else{
                prestackButton.isHidden = false
            reset.isHidden = false
            setting.isHidden = false
            save.isHidden = false
            hideButton.setTitle("Hide", for: UIControl.State.normal)
            hideButton.alpha = 1
            
            hidestate = false
            
        }
        
        
        
        
    }
    

}
extension ViewController : SettingsViewControllerDelegate{
    func SettingsViewControllerFinished(_settinsViewController: settingViewController){
        self.brushWidth = _settinsViewController.brushwidth
        
        self.red = _settinsViewController.red
        self.green = _settinsViewController.green
        self.blue = _settinsViewController.blue
        self.opacity = _settinsViewController.opacity
        self.brushSize()
    }
    
    
}
